#ifndef __HBDETECT_H
#define __HBDETECT_H
        #include "math.h"

        #define TH 				0.4516
        #define MS95            28
        #define PRE_BLANK 		25
        #define MIN_PEAK_AMP 	7
        #define MEMMOVELEN  	7

        // 定义变量
        extern int isRPeak;
        // 定义函数
        extern int QRSDet(int data);
        extern int Peak( int data);
        extern int NewPeak(int aPeak); 
        extern int DetThresh(int qmean, int nmean);	 
        extern double mean(int *arr, int LENGTH); 
        extern void Datamove(int *pBuffer, int *arr, int Length);

        void Shift2Left(int *array, int Length);


#endif


