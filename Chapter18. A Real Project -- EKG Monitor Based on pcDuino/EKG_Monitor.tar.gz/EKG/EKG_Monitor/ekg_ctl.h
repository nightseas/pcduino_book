#ifndef EKG_CTL_H
#define EKG_CTL_H

#include "system.h"

extern quint16 EKG_Data_Buff[];
extern int EKG_HeartRate;

#define EKG_DATA_MAX        65535
#define EKG_DATA_LEN        800
#define EKG_WAVE_HEIGHT     500
#define EKG_WAVE_WIDHT      EKG_DATA_LEN

void EKG_InitData(void);

#ifdef PCDUINO

#define EKG_MAX1134_CS_PIN      9
#define EKG_MAX1134_CS_LOW()    digitalWrite(EKG_MAX1134_CS_PIN, LOW)
#define EKG_MAX1134_CS_HIGH()   digitalWrite(EKG_MAX1134_CS_PIN, HIGH)

void EKG_ReadToBuff(void);
quint16 EKG_ReadData(void);
quint16 EKG_ConvertData(quint16 inData);
quint16 EKG_ChangeScope(quint16 inData);

void EKG_SampleTimer_Init(long s,long us);

#endif // PCDUINO
#endif // EKG_CTL_H

