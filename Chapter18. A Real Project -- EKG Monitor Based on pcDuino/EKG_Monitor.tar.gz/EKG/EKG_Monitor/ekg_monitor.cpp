#include <QtCore>
#include <QPainter>
#include "ekg_monitor.h"
#include "ui_ekg_monitor.h"

#define GUI_REFRESH_TIME    2000

EKG_Monitor::EKG_Monitor(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::EKG_Monitor)
{
    ui->setupUi(this);

    TimerRefresh = new QTimer(this);
    connect(TimerRefresh,SIGNAL(timeout()),this,SLOT(TimerUpdated()));
}

// ********************* Private Slots *************************

EKG_Monitor::~EKG_Monitor()
{
    this->TimerRefresh->stop();
    ui->labelHeartRate->setText("0");
    delete ui;
}

void EKG_Monitor::on_buttonStart_clicked()
{
    EKG_InitData();
    this->TimerRefresh->start(GUI_REFRESH_TIME);
    ui->buttonStart->setEnabled(false);
}

void EKG_Monitor::on_buttonHome_clicked()
{
    //EKG_InitData();
    this->TimerRefresh->stop();
    ui->buttonStart->setEnabled(true);
    this->close();
}

void EKG_Monitor::TimerUpdated()
{
    this->UpdateData();
    ui->labelHeartRate->setText(QString::number(EKG_HeartRate));
    update();
}

// ********************* Draw Wave *************************

void EKG_Monitor::paintEvent(QPaintEvent *)
{
    QPainter pt(this);
    int i;
    QPen pn;
    QBrush bs;

    pt.setRenderHint(QPainter::Antialiasing, true);

    //Draw Lines
    pn.setColor(Qt::lightGray);
    pn.setWidth(2);
    pn.setStyle(Qt::DashLine);
    pt.setPen(pn);
    pt.drawRect(0,0,EKG_WAVE_WIDHT, EKG_WAVE_HEIGHT);
    //Horizontal
    pt.drawLine(0, EKG_WAVE_HEIGHT/4, EKG_WAVE_WIDHT, EKG_WAVE_HEIGHT/4);
    pt.drawLine(0, EKG_WAVE_HEIGHT/2, EKG_WAVE_WIDHT, EKG_WAVE_HEIGHT/2);
    pt.drawLine(0, EKG_WAVE_HEIGHT*3/4, EKG_WAVE_WIDHT, EKG_WAVE_HEIGHT*3/4);
    //Vertical
    pt.drawLine(EKG_WAVE_WIDHT/4, 0, EKG_WAVE_WIDHT/4, EKG_WAVE_HEIGHT);
    pt.drawLine(EKG_WAVE_WIDHT/2, 0, EKG_WAVE_WIDHT/2, EKG_WAVE_HEIGHT);
    pt.drawLine(EKG_WAVE_WIDHT*3/4, 0, EKG_WAVE_WIDHT*3/4, EKG_WAVE_HEIGHT);

    //Draw EKG Wave
    pn.setColor(Qt::darkBlue);
    pn.setStyle(Qt::SolidLine);
    pn.setWidth(2);
    pt.setPen(pn);

    for(i=0;i<EKG_WAVE_WIDHT-1;i++)
    {
        pt.drawLine(i, EKG_WAVE_HEIGHT - EKG_ChangeScope(EKG_Data_Buff[i]), (i+1), EKG_WAVE_HEIGHT - EKG_ChangeScope(EKG_Data_Buff[i+1]));
    }
}



// ********************* Data Sample Functions *************************

void EKG_Monitor::UpdateData()
{
#ifdef PCDUINO
    EKG_ReadToBuff();
#else
    //For simulation
    int i;

    for(i=0;i<EKG_DATA_LEN-1;i++)
    {
        EKG_Data_Buff[i]=EKG_WAVE_HEIGHT*3/2-(qrand()%(EKG_DATA_MAX/3)+EKG_DATA_MAX/6)*3*EKG_WAVE_HEIGHT/EKG_DATA_MAX;
    }
#endif
}

