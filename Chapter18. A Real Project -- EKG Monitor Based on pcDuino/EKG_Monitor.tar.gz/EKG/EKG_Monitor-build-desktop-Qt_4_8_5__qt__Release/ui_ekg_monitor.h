/********************************************************************************
** Form generated from reading UI file 'ekg_monitor.ui'
**
** Created by: Qt User Interface Compiler version 4.8.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EKG_MONITOR_H
#define UI_EKG_MONITOR_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_EKG_Monitor
{
public:
    QWidget *centralWidget;
    QPushButton *buttonStart;
    QPushButton *buttonHome;
    QLabel *label;
    QLabel *labelHeartRate;

    void setupUi(QMainWindow *EKG_Monitor)
    {
        if (EKG_Monitor->objectName().isEmpty())
            EKG_Monitor->setObjectName(QString::fromUtf8("EKG_Monitor"));
        EKG_Monitor->resize(1000, 500);
        centralWidget = new QWidget(EKG_Monitor);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        buttonStart = new QPushButton(centralWidget);
        buttonStart->setObjectName(QString::fromUtf8("buttonStart"));
        buttonStart->setGeometry(QRect(840, 356, 131, 41));
        buttonHome = new QPushButton(centralWidget);
        buttonHome->setObjectName(QString::fromUtf8("buttonHome"));
        buttonHome->setGeometry(QRect(840, 410, 131, 41));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(840, 40, 111, 17));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);
        labelHeartRate = new QLabel(centralWidget);
        labelHeartRate->setObjectName(QString::fromUtf8("labelHeartRate"));
        labelHeartRate->setGeometry(QRect(820, 70, 131, 71));
        QFont font1;
        font1.setPointSize(48);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(50);
        labelHeartRate->setFont(font1);
        labelHeartRate->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        EKG_Monitor->setCentralWidget(centralWidget);

        retranslateUi(EKG_Monitor);

        QMetaObject::connectSlotsByName(EKG_Monitor);
    } // setupUi

    void retranslateUi(QMainWindow *EKG_Monitor)
    {
        EKG_Monitor->setWindowTitle(QApplication::translate("EKG_Monitor", "EKG_Monitor", 0, QApplication::UnicodeUTF8));
        buttonStart->setText(QApplication::translate("EKG_Monitor", "&Start", 0, QApplication::UnicodeUTF8));
        buttonHome->setText(QApplication::translate("EKG_Monitor", "&Home", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("EKG_Monitor", "Heart Rate", 0, QApplication::UnicodeUTF8));
        labelHeartRate->setText(QApplication::translate("EKG_Monitor", "0", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class EKG_Monitor: public Ui_EKG_Monitor {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EKG_MONITOR_H
