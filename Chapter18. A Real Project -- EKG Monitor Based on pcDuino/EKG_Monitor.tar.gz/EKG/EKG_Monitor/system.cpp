#include "system.h"
#include "ekg_ctl.h"
#ifdef PCDUINO

void Sys_InitPeripheral(void)
{
    pinMode(EKG_MAX1134_CS_PIN, OUTPUT);
    EKG_MAX1134_CS_HIGH();

    //初始化SPI接口
    SPI.begin();
    SPI.setDataMode(SPI_MODE2); //CPOL=1, CPHA=1
    SPI.setBitOrder(MSBFIRST);
    SPI.setClockDivider(SPI_CLOCK_DIV8); //SPI时钟为8分频时钟,1.5MHz
}

void Sys_InitBoard(void)
{
    init();
    printf("C library init done!\n");
    Sys_InitPeripheral();
    printf("Peripheral init done!\n");
}



#endif
