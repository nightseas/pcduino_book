#ifndef SYSTEM_H
#define SYSTEM_H
#include <QtCore>
#include "signal.h"
#define PCDUINO

#ifdef PCDUINO


#include "core.h"
#include <SPI.h>

void Sys_InitBoard(void);
void Sys_InitPeripheral(void);


#endif // PCDUINO
#endif // SYSTEM_H
