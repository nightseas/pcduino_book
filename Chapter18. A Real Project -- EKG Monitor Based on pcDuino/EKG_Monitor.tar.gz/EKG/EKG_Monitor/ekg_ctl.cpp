#include "ekg_ctl.h"
#include "filter.h"
#include "hbdetect.h"
#include <sys/time.h>

#define DIGITAL_FILTER

quint16 EKG_Data_Buff[EKG_DATA_LEN];
quint32 EKG_Samp_Cnt = 0;
int EKG_HeartRate = 0;

void EKG_InitData(void)
{
    memset(EKG_Data_Buff, 0, sizeof(EKG_Data_Buff));
#ifdef PCDUINO
    EKG_SampleTimer_Init(0, 0);
    EKG_Samp_Cnt = 0;
#endif
}

quint16 EKG_ChangeScope(quint16 inData)
{
    quint32 outData;

    outData = inData * EKG_WAVE_HEIGHT / 20000 - EKG_WAVE_HEIGHT / 2;
    if(outData >= EKG_WAVE_HEIGHT)
        outData = EKG_WAVE_HEIGHT -1;
    return  (quint16)outData;
}

#ifdef PCDUINO
#define MAX1134_FB          (0x1<<7)  /* First bit */
#define MAX1134_UNI         (0x1<<6)  /* 1 = unipolar, 0 = bipolar */
#define MAX1134_ICLK        (0x1<<5)  /* Selects the internal or external conversion clock. 1 = internal, 0 = external. */
#define MAX1134_PD          (0x2<<3)  /* Software power-down mode */
#define MAX1134_START       (0x1<<3)  /* Start calibration: starts internal calibration */
#define MAX1134_SACC        (0x0<<3)  /* 24 external clocks per conversion (short acquisition mode) */
#define MAX1134_LACC        (0x3<<3)  /* 32 external clocks per conversion (long acquisition mode)  */
#define MAX1134_P2          (0x1<<2)  /* I/O P2 */
#define MAX1134_P1          (0x1<<1)  /* I/O P1 */
#define MAX1134_P0          (0x1<<0)  /* I/O P0 */

#define MAX1134_CMD_EKG   (MAX1134_FB + MAX1134_UNI + MAX1134_SACC + MAX1134_P2 + MAX1134_P0)
#define MAX1134_CMD_SHUT  (MAX1134_FB + MAX1134_UNI + MAX1134_ICLK + MAX1134_PD)

#define DUMMY_BYTE          0x00
#define EKG_SAMPLE_PERIOD   3333

static quint16 EKG_BaseLine = 0;

quint16 EKG_ADC_ReadData(void)
{
    quint16 Data = 0, DataH = 0, DataL = 0;

    /* Select the Device: Chip Select low */
    EKG_MAX1134_CS_LOW();
    /* Send "MAX1134_CMD_EKG" instruction */
    SPI.transfer(MAX1134_CMD_EKG, SPI_CONTINUE);
    /* Read the high byte */
    DataH = SPI.transfer(DUMMY_BYTE, SPI_CONTINUE);
    /* Read the low byte */
    DataL = SPI.transfer(DUMMY_BYTE, SPI_LAST);
    /* Deselect the Device: Chip Select high */
    EKG_MAX1134_CS_HIGH();

    Data = (DataH << 8) | (DataL & 0xFFFF);
    return Data;
}

quint16 EKG_ConvertData(quint16 inData)
{
#ifdef DIGITAL_FILTER
    int outData;
    outData = Digital_filter((int)(inData), IIR2_25Hz_Table, NULL);

    if( outData < 0 )
    {
        EKG_BaseLine = (quint16)(abs(outData));
        outData = EKG_BaseLine ;
    }
    else
    {
        outData = (quint16)(outData) + EKG_BaseLine;
    }
    EKG_HeartRate = QRSDet(outData);
    return outData;
#else
    return inData;
#endif
}

quint16 EKG_ReadData(void)
{
    quint16 adc_resault = 0;
    adc_resault = EKG_ADC_ReadData();
    adc_resault = EKG_ConvertData(adc_resault);    
    return (adc_resault);
}

void EKG_SampleTimer_Handler(int irq)
{
    switch(irq)
    {
    case SIGALRM:
        if(EKG_Samp_Cnt < EKG_DATA_LEN)
            EKG_Data_Buff[EKG_Samp_Cnt] = EKG_ReadData();
        EKG_Samp_Cnt++;
        break;

    default:
        break;
    }
}

void EKG_SampleTimer_Init(long s,long us)
{
    struct itimerval interrupt_time;

    interrupt_time.it_value.tv_sec = s;
    interrupt_time.it_value.tv_usec = us;
    interrupt_time.it_interval.tv_sec = s;
    interrupt_time.it_interval.tv_usec = us;

    setitimer(ITIMER_REAL, &interrupt_time, NULL);
    signal(SIGALRM, EKG_SampleTimer_Handler);

    printf("Set sample interrupt time: %lds , %ldus\n", s, us);
}

void EKG_ReadToBuff(void)
{    
    EKG_SampleTimer_Init(0, EKG_SAMPLE_PERIOD);
    while(EKG_Samp_Cnt < EKG_DATA_LEN)
    {
        pause();
    }
    EKG_SampleTimer_Init(0, 0);
    EKG_Samp_Cnt = 0;
}


#endif // PCDUINO
