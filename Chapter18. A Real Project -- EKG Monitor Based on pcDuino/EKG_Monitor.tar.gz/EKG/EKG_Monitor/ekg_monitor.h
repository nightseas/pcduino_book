#ifndef EKG_MONITOR_H
#define EKG_MONITOR_H

#include <QMainWindow>
#include "ekg_ctl.h"

namespace Ui {
class EKG_Monitor;
}

class EKG_Monitor : public QMainWindow
{
    Q_OBJECT

public:
    explicit EKG_Monitor(QWidget *parent = 0);
    ~EKG_Monitor();

    QTimer *TimerRefresh;

private slots:
    void TimerUpdated();
    void on_buttonStart_clicked();
    void on_buttonHome_clicked();

private:
    Ui::EKG_Monitor *ui;
    void paintEvent(QPaintEvent *);

    void UpdateData();
};

#endif // EKG_MONITOR_H
