#include <QtGui/QApplication>
#include "ekg_monitor.h"
#include "system.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    EKG_Monitor w;
    w.show();
    Sys_InitBoard();
    return a.exec();
}
