#ifndef _CORE_H__
#define _CORE_H__
#include "Arduino.h"
#include "wiring_private.h"
#endif
