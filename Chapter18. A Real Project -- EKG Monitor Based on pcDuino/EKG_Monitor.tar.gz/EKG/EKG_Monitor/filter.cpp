#include "hbdetect.h"
#include "filter.h"

double IIR2_25Hz_Table[6] = {
	1.000000000000000, -1.279632424997809, 0.477592250072517,    //Y
  0.049489956268677, 0.098979912537354, 0.049489956268677,     //X	
};

double IIR2_Stop50Hz_Table[6] = {
    1.000000000000000, -0.950000000000000, 0.900000000000000,    //Y
    0.950000000000000, -0.950000000000000, 0.950000000000000,     //X
};

struct __typeFilterBuff
{
	double Hp[6];
	double Lp[6];
    double Bandstop[6];
};
struct __typeFilterBuff filter_buff_s;

int Digital_filter(int data, double *LpCoefs, double *HpCoefs)
{
    int fdata;

    fdata = filter_lowpass(LpCoefs, filter_buff_s.Lp, data);
    fdata = filter_bandstop(IIR2_Stop50Hz_Table, filter_buff_s.Bandstop, fdata);
	
    return fdata;
}

double filter_lowpass(const double *pTable, double *pBuffer, int Xn)
{
	pBuffer[2] = pBuffer[1];
	pBuffer[1] = pBuffer[0];

	//X
	pBuffer[5] = pBuffer[4];
	pBuffer[4] = pBuffer[3];
	pBuffer[3] = (double)Xn;

	pBuffer[0] =
	(pBuffer[3] + pBuffer[5]) * pTable[3] +
	pBuffer[4] * pTable[4] -
	pBuffer[1] * pTable[1] -
	pBuffer[2] * pTable[2];

	return pBuffer[0];
}

double filter_bandstop(const double *pTable, double *pBuffer, int Xn)
{
	pBuffer[2] = pBuffer[1];
    pBuffer[1] = pBuffer[0];

	pBuffer[5] = pBuffer[4];
	pBuffer[4] = pBuffer[3];
	pBuffer[3] = (double)Xn;

	pBuffer[0] =
		pBuffer[3] * pTable[3] +
		pBuffer[4] * pTable[4] +
		pBuffer[5] * pTable[5] -

		pBuffer[1] * pTable[1] -
		pBuffer[2] * pTable[2];

	return pBuffer[0];
}

