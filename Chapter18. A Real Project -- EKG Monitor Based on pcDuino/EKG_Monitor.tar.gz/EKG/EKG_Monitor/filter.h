#ifndef __FILTER_H
#define __FILTER_H

        #include <stdio.h>
        #include "stdlib.h"

        #define DERIV_LENGTH 3
        #define WINDOW_WIDTH 24


        extern double IIR2_25Hz_Table[];
        extern double IIR2_Stop50Hz_Table[];
         

        int Digital_filter(int data, double *LpCoefs, double *HpCoefs);

        double filter_lowpass(const double *pTable, double *pBuffer, int Xn);
        double filter_bandstop(const double *pTable, double *pBuffer, int Xn);


#endif


