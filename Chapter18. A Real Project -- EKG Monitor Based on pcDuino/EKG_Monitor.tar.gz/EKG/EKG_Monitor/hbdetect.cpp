#include "hbdetect.h"
#include "filter.h"
#include "string.h"
static int HeartRate;
static int preBlankCnt, tempPeak;
int isRPeak;

int deriv(int datum)
{
	static int derBuff[DERIV_LENGTH], derI = 0 ;
	int y ;

	y = datum - derBuff[derI] ;
	derBuff[derI] = datum ;
	if(++derI == DERIV_LENGTH)
		derI = 0 ;
	return(y) ;
}
int mvwint(int datum)
{
	static long sum = 0 ;
    static int filter_lowpass[WINDOW_WIDTH], ptr = 0 ;
	int output;

	sum += datum ;
    sum -= filter_lowpass[ptr] ;
    filter_lowpass[ptr] = datum ;
	if(++ptr == WINDOW_WIDTH)
		ptr = 0 ;
	if((sum / WINDOW_WIDTH) > 48000)
		output = 48000 ;
	else
		output = sum / WINDOW_WIDTH ;
	return(output) ;
}
void Shift2Left(int *array, int Length)
{
  static unsigned char i;
	for(i=0; i<(Length-1); i++)
        array[i] = array[i+1];
}
int QRSDet(int datum)
{
	static int det_thresh, qpkcnt = 0;
	static int qrsbuf[8], noise[8];
	static int qmean, nmean;
	static int sincePeakCnt = 0, HRCount = 0, HeartRateTemp = 0;
  static int FrontInterval;
	static int HeartRateBuf[8];
	int newPeak, aPeak;
	int fdatum;
	
	fdatum = deriv(datum);
	fdatum = abs(fdatum);
	fdatum = mvwint(fdatum);
	
	aPeak = Peak(fdatum);
	if(aPeak < MIN_PEAK_AMP)
	{
		aPeak = 0;
	}
	newPeak = NewPeak(aPeak);
	if (qpkcnt < 8)
	{
		if (newPeak > 0)
		{
				isRPeak = 1; 		
				qrsbuf[qpkcnt] = newPeak;
				++qpkcnt;
				FrontInterval = FrontInterval + sincePeakCnt;
				sincePeakCnt = 0;
				if (qpkcnt == 8)
				{
						qmean = mean(qrsbuf, 8);
						nmean = 0;
						det_thresh = DetThresh((int)qmean, (int)nmean);
						HeartRate = 63000 / FrontInterval + 1;
				}
		}
		else if (qpkcnt > 0)
				sincePeakCnt = sincePeakCnt + 1;
	}
	else 
	{
		sincePeakCnt = sincePeakCnt + 1;
				if (newPeak > 0)
				{
						if (newPeak > det_thresh)
						{
								isRPeak = 1;		
								memmove(qrsbuf, qrsbuf, MEMMOVELEN) ;
								qrsbuf[7] = newPeak;
								qmean = mean(qrsbuf, 8);
								det_thresh = DetThresh((int)qmean, (int)nmean); 
								if (HRCount < 8)
								{
									HeartRate = 9000 / sincePeakCnt + 1;  
									HeartRateBuf[HRCount++] = HeartRate;
								}
								else
								{
										HeartRateTemp = 9000 / sincePeakCnt + 1;
										HeartRate = (int)mean(HeartRateBuf, 8);
										memmove(HeartRateBuf, HeartRateBuf, MEMMOVELEN)	;
										HeartRateBuf[7] = HeartRateTemp;
								}
								sincePeakCnt = 0;
						}
						else if (newPeak < det_thresh)
						{
								memmove(noise, noise, MEMMOVELEN);
								noise[7] = newPeak;
								nmean = mean(noise, 8);
								det_thresh = DetThresh((int)qmean, (int)nmean);
						}
				}
	}
	return HeartRate;	
}
int Peak( int datum )
{
	static int max = 0, timeSinceMax = 0, lastDatum ;
	int pk = 0 ;

	if(timeSinceMax > 0)
		++timeSinceMax ;

	if((datum > lastDatum) && (datum > max))
		{
		max = datum ;
		if(max > 200) 		
			timeSinceMax = 1 ;
		}

	else if(datum < (max >> 1))
		{
		pk = max ;        
		max = 0 ;
		timeSinceMax = 0 ;
		}

	else if(timeSinceMax > MS95)   
		{
		pk = max ;    			   
		max = 0 ;
		timeSinceMax = 0 ; 
		}
	lastDatum = datum ;
	return(pk) ;
}
int NewPeak(int aPeak)
{
	int newPeak = 0;
	if ((aPeak > 0) && (preBlankCnt == 0))			
	{																						
		tempPeak = aPeak;
		preBlankCnt = PRE_BLANK;			
	}

	else if ((aPeak == 0) && (preBlankCnt > 0))	
	{																						
		if (--preBlankCnt == 0)
		newPeak = tempPeak;
	}

	else if (aPeak > 0)							
	{										
		if (aPeak > tempPeak)				
		{
			tempPeak = aPeak;
			preBlankCnt = PRE_BLANK; 		
		}
		else if (--preBlankCnt == 0)
			newPeak = tempPeak;
	}
	return newPeak;
}
int DetThresh(int qmean, int nmean)
{
	int thrsh, dmed;
	double temp;
	dmed = qmean - nmean;
	temp = dmed;
	temp = temp * TH;
	dmed = (int)temp;
	thrsh = nmean + dmed; 	/* dmed * THRESHOLD */
	return (thrsh);
}

double mean(int *arr, int LENGTH)
{
	long sum = 0;
	int Loop;
	for (Loop = 0; Loop < LENGTH; Loop++)
		sum += arr[Loop];
	sum /= LENGTH;
	return sum;
}

void filter_lowpassmove(int *pBuffer, int *arr, int Length)
{
	int i;
	for(i = 0; i < Length; i++)		  
		pBuffer[i] = arr[i+1];
}


